package assignment4;

import java.awt.Color;
import java.io.File;
import java.util.Scanner;

import javax.swing.JFileChooser;

import edu.princeton.cs.introcs.StdDraw;

public class CookieClicker {

	public static void main(String[] args) {

// Score
   int score = 0;
   boolean wasPressed = false;

   StdDraw.clear();

// Background
   StdDraw.setPenColor(StdDraw.WHITE);

// Text
   StdDraw.setPenColor(StdDraw.BLACK);
   StdDraw.text(0.5, 0.8, "Cookie Clicker");

// Cookie Base
   StdDraw.setPenColor(179,121,59);
   StdDraw.filledCircle(0.5, 0.5, 0.25);

// Cookie Chips
   StdDraw.setPenColor(68,38,11);
   StdDraw.filledCircle(0.4, 0.6, 0.04);
   StdDraw.filledCircle(0.5, 0.5, 0.04);
   StdDraw.filledCircle(0.6, 0.6, 0.04);
   StdDraw.filledCircle(0.4, 0.4, 0.04);
   StdDraw.filledCircle(0.6, 0.4, 0.04);

// Cookie is Clicked
   /* if (StdDraw.isMousePressed()) {
	  StdDraw.setPenColor(242, 222, 201);
	  StdDraw.filledCircle(0.5, 0.5, 0.25);
   }
	  */

// Cookie was clicked
	while (true) {
		boolean isPressed = StdDraw.isMousePressed();
		
		if (isPressed && !wasPressed) {
			double dx = StdDraw.mouseX()-10;
			double dy = StdDraw.mouseY()-10;

			if (Math.sqrt(dx * dx + dy * dy) <= 0.25) {
				score++;
			}
		}

		wasPressed = isPressed;

		// Redraw the cookie and display the current score here.
		StdDraw.pause(20);

		}


	}
}
